package com.bootcamp;

public class Nilai {
    private double bInggris;
    private double fisika;
    private double algoritma;

    public double getbInggris() {
        return bInggris;
    }

    public void setbInggris(double bInggris) {
        this.bInggris = bInggris;
    }

    public double getFisika() {
        return fisika;
    }

    public void setFisika(double fisika) {
        this.fisika = fisika;
    }

    public double getAlgoritma() {
        return algoritma;
    }

    public void setAlgoritma(double algoritma) {
        this.algoritma = algoritma;
    }
}
